#include "comboboxdelegate.h"
#include <QSqlQuery>
#include <QSqlError>
#include <QMessageBox>

ComboBoxDelegate::ComboBoxDelegate(QObject *parent)
    : QStyledItemDelegate(parent)
{
}

QWidget *ComboBoxDelegate::createEditor(QWidget *parent, const QStyleOptionViewItem &, const QModelIndex &index) const
{
    QComboBox *comboBox = new QComboBox(parent);

    // Add items for specific columns
    if (index.column() == 4) { // Year Level column
        comboBox->addItem("First Year");
        comboBox->addItem("Second Year");
        comboBox->addItem("Third Year");
        comboBox->addItem("Fourth Year");
        comboBox->addItem("Ongoing");
    } else if (index.column() == 5) { // Gender column
        comboBox->addItem("Male");
        comboBox->addItem("Female");
    } else if (index.column() == 6) { // Course Code column (assuming it's the 7th column, index 6)
        comboBox->addItems(fetchCourseCodes());
    }

    return comboBox;
}

void ComboBoxDelegate::setEditorData(QWidget *editor, const QModelIndex &index) const
{
    QString value = index.model()->data(index, Qt::EditRole).toString();
    QComboBox *comboBox = static_cast<QComboBox*>(editor);
    int comboIndex = comboBox->findText(value);
    if (comboIndex >= 0) {
        comboBox->setCurrentIndex(comboIndex);
    }
}

void ComboBoxDelegate::setModelData(QWidget *editor, QAbstractItemModel *model, const QModelIndex &index) const
{
    QComboBox *comboBox = static_cast<QComboBox*>(editor);
    QString value = comboBox->currentText();
    model->setData(index, value, Qt::EditRole);
}

void ComboBoxDelegate::updateEditorGeometry(QWidget *editor, const QStyleOptionViewItem &option, const QModelIndex &) const
{
    editor->setGeometry(option.rect);
}

QStringList ComboBoxDelegate::fetchCourseCodes() const
{
    QStringList courseCodes;
    QSqlQuery query("SELECT [Course Code] FROM Courses");
    while (query.next()) {
        courseCodes << query.value(0).toString();
    }
    return courseCodes;
}
